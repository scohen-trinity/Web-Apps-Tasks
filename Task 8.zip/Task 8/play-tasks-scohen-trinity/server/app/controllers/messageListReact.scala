package controllers

import javax.inject._

import play.api.mvc._
import play.api.i18n._
import models.MessageListInMemoryModel
import play.api.libs.json._
import models._

@Singleton
class messageListReact @Inject() (cc: ControllerComponents) extends AbstractController(cc) {
    def load = Action {implicit request =>
        Ok(views.html.reactMessagesMain())
    }

    def validate = Action {implicit request =>
        request.body.asJson.map { ud => 
            ud.as[UserData] match {
                case userData: UserData =>
                    if(MessageListInMemoryModel.validateUser(userData.username, userData.password)) {
                        Ok(Json.toJson(true)).withSession("username" -> userData.username, "csrfToken" -> play.filters.csrf.CSRF.getToken.get.value)
                    } else {
                        Ok(Json.toJson(false))
                    }
                case _ =>
                    BadRequest("Invalid JSON format")
            }
        }.getOrElse {
            BadRequest("Expecting JSON data")
        }
    }

    def getGeneralMessages = Action { implicit request =>
        val usernameOption = request.session.get("username")
        usernameOption.map { username =>
            Ok(Json.toJson(MessageListInMemoryModel.getGeneralMessages(username)))
        }.getOrElse(Ok(Json.toJson(Seq.empty[String])))
    }

    def getPersonalMessages = Action {implicit request =>
        val usernameOption = request.session.get("username")
        usernameOption.map { username =>
            println(s"$username")
            Ok(Json.toJson(MessageListInMemoryModel.getPersonalMessages(username)))
        }.getOrElse(Ok(Json.toJson(Seq.empty[String])))
    }

    def createUser = Action {implicit request =>
        request.body.asJson.map { ud => 
            ud.as[UserData] match {
                case userData: UserData =>
                    if(MessageListInMemoryModel.createUser(userData.username, userData.password)) {
                        Ok(Json.toJson(true))
                    } else {
                        Ok(Json.toJson(false))
                    }
                case _ =>
                    BadRequest("Invalid JSON format")
            }
        }.getOrElse {
            BadRequest("Expecting JSON data")
        }
    }

    def addGeneralMessage = Action { implicit request =>
        val usernameOption = request.session.get("username")
        usernameOption.map { username => 
            request.body.asJson.map { body =>
                Json.fromJson[String](body) match {
                    case JsSuccess(message, path) =>
                        MessageListInMemoryModel.addGeneralMessage(message);
                        Ok(Json.toJson(true))
                    case e @ JsError(_) => Redirect(routes.messageListReact.load)
                }   
            }.getOrElse(Ok(Json.toJson(false)))
        }.getOrElse(Ok(Json.toJson(false)))
    }

    def addPersonalMessage = Action(parse.json) { implicit request =>
        val usernameOption = request.session.get("username")
        usernameOption.map { username => 
            val newPersonalOpt = (request.body \ "newPersonal").asOpt[String]
            val senderOpt = (request.body \ "sender").asOpt[String]
            
            (newPersonalOpt, senderOpt) match {
                case (Some(newPersonal), Some(sender)) => 
                    MessageListInMemoryModel.addPersonalMessage(newPersonal, username, sender)
                    Ok(Json.toJson(true))
                case _ =>
                    BadRequest(Json.toJson(false))
                }
            }.getOrElse {
                BadRequest(Json.toJson(false))
            }
    }

    def deleteGeneralMessage = TODO
}