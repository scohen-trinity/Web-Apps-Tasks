package shared

object SharedMessages {
  def itWorks = "It works!"
}
